"""Commands for the registered, single-seed brain / Sokoban study."""
import argparse
from registry import STUDY, read


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','benchmark','train','evaluate','analyze','run','status','test','validate','worker'])
    p.add_argument('--run-id')
    p.add_argument('--module')
    p.add_argument('--resume',action='store_true')
    p.add_argument('--verify',action='store_true')
    p.add_argument('--config')
    a=p.parse_args()
    if a.command=='prepare':
        from tasks import prepare,separate_wall_families
        from memory_tasks import prepare_memory
        prepare();prepare_memory();separate_wall_families()
    elif a.command=='test':
        import unittest
        result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(STUDY/'code'),pattern='test_*.py'))
        return 0 if result.wasSuccessful() else 1
    elif a.command=='validate':
        from validation import validate
        return validate()
    elif a.command=='status':
        import json
        for name in ['supervisor.json','backend.json','summary.json']:
            path=STUDY/name
            if path.exists(): print(json.dumps({name:read(path)},ensure_ascii=False))
        if (STUDY/'supervisor.json').exists():
            current=read(STUDY/'supervisor.json').get('run_id')
            if current and (STUDY/'runs'/current/'progress.json').exists():
                progress=read(STUDY/'runs'/current/'progress.json')
                keys=('status','depth','updates','elapsed','solved','total','original_status','original_steps')
                print(json.dumps({'current_run':current,'progress':{k:progress[k] for k in keys if k in progress}},ensure_ascii=False))
    else:
        from execution import dispatch
        return dispatch(a)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
