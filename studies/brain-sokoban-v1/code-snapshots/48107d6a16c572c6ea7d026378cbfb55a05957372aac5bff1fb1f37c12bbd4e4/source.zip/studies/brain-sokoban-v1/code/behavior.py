"""Batched autonomous evaluation with complete per-decision scientific records."""
import time
import numpy as np
import torch
import bootstrap
from game import encode,legal,restore,solved,state_from,step
from curriculum import static_dead


class Features:
    """An assessment-local cache; never survives a parameter update."""
    def __init__(self,encoder):self.encoder=encoder;self.cache={}
    def encode(self,boards,check=lambda:None):
        keys=[b.astype('uint8').tobytes() for b in boards]
        missing={k:b for k,b in zip(keys,boards) if k not in self.cache}
        if missing:self.cache.update(zip(missing,self.encoder.encode(np.stack(list(missing.values())),check)))
        return np.stack([self.cache[k] for k in keys])


def rollouts(encoder,head,levels,check=lambda:None,max_steps=512,features=None):
    t=time.perf_counter();bank=features or Features(encoder)
    maps=[restore(l) for l in levels];states=[state_from(l['start']) for l in levels]
    seen=[{s} for s in states];records=[dict(task=l['id'],family=l.get('family_id'),status='running',decisions=[]) for l in levels]
    for _ in range(max_steps):
        check();active=[]
        for i,r in enumerate(records):
            if r['status']!='running':continue
            if solved(maps[i],states[i]):r['status']='solved'
            elif static_dead(maps[i],states[i]):r['status']='proven_corner_deadlock'
            elif not legal(maps[i],states[i]).any():r['status']='blocked'
            else:active.append(i)
        if not active:break
        boards=np.stack([encode(maps[i],states[i]) for i in active]);f=bank.encode(boards,check)
        with torch.no_grad():q=head(torch.as_tensor(f,device='cuda'))['final_logits'].cpu().numpy()
        if not np.isfinite(q).all():raise FloatingPointError('Nonfinite policy logits')
        for k,i in enumerate(active):
            mask=legal(maps[i],states[i]);a=int(np.where(mask,q[k],-np.inf).argmax())
            records[i]['decisions'].append(dict(state=[states[i][0],list(states[i][1])],
                action=a,logits=q[k].tolist(),features=f[k].tolist(),legal=mask.tolist()))
            states[i]=step(maps[i],states[i],a)
            if solved(maps[i],states[i]):records[i]['status']='solved'
            elif states[i] in seen[i]:records[i]['status']='repeated_state'
            else:seen[i].add(states[i])
    for r in records:
        if r['status']=='running':r['status']='action_limit'
        r['actions']=[d['action'] for d in r['decisions']];r['steps']=len(r['actions'])
    return dict(records=records,seconds=time.perf_counter()-t,complete=True)
