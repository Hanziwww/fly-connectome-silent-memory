"""Tests for experimental validity and continuation decisions; no training mocks."""
import unittest
import numpy as np
import torch
import bootstrap
from game import restore,state_from,step,solved,canonical
from registry import STUDY,read
from tasks import transform
from training import extension_allowed,objective


class StudyTests(unittest.TestCase):
    def test_locked_task_families_and_solutions(self):
        levels=read(STUDY/'tasks/levels.json')
        self.assertEqual(len(levels),34);self.assertEqual(len({l['family_id'] for l in levels}),34)
        for l in levels:
            m=restore(l);s=state_from(l['start'])
            for a in l['reference_actions']:
                s=step(m,s,a);self.assertIsNotNone(s)
            self.assertTrue(solved(m,s));self.assertEqual(len(l['reference_actions']),l['optimal_steps'])
            for k in range(4):
                for flip in (False,True):
                    v=transform(l,k,flip);m=restore(v);s=state_from(v['start'])
                    for a in v['reference_actions']:s=step(m,s,a)
                    self.assertTrue(solved(m,s));self.assertEqual(canonical(m),canonical(restore(l)))

    def test_extension_uses_same_entry_and_retention(self):
        s=dict(promotions=1,phase_promotions=1,depth=4,phase_depth=4,phase_margin=-.1)
        self.assertTrue(extension_allowed(s,dict(retained=True,bridge_margin=-.07)))
        self.assertFalse(extension_allowed(s,dict(retained=False,bridge_margin=1)))
        self.assertFalse(extension_allowed(dict(s,depth=3),dict(retained=True,bridge_margin=1)))
        self.assertTrue(extension_allowed(dict(s,promotions=2),dict(retained=False,bridge_margin=-1)))

    def test_recovery_repairs_negative_anchor(self):
        data=dict(legal=np.ones((2,4),bool),clauses=[dict(atoms=[(0,(0,))]),dict(atoms=[(1,(1,))])],
                  bridge_clause=0,protected_clauses=[1])
        q=torch.tensor([[0.,0.,0.,0.],[1.,-1.,0.,0.]],requires_grad=True)
        loss=objective(q,data,'recovery')[0];loss.backward();self.assertLess(q.grad[1,1].item(),0)
        q.grad=None;objective(q,data,'entry_only')[0].backward();self.assertEqual(q.grad[1].abs().sum(),0)

    def test_schedule_pairing_and_no_seed_repeats(self):
        jobs=read(STUDY/'schedule.json');self.assertEqual({j['seed'] for j in jobs},{10})
        self.assertEqual(len({j['id'] for j in jobs}),len(jobs))
        self.assertEqual(sum(j['module']=='difficulty' for j in jobs),24)
        for j in jobs:
            if j['module']=='controls':self.assertIsNone(j['parent'])


if __name__=='__main__':unittest.main()
