"""Full-connectome adapter; precision, state and structural controls are explicit."""
import dataclasses
import time
import numpy as np
import torch
from torch import nn
import bootstrap
from brain_model import FullBrain
from common import cpu_state
from readout_models import ActivityLinear, output
from registry import ROOT, STUDY, write

STATE_FIELDS=('v','g','g_slow','g_slow_cls','refrac','drive','poisson_p','rate',
              'spikes','adapt','res','spike_buf','spike_counts')


class Matrix:
    def __init__(self, base, dtype):
        self.base=base.to(dtype=dtype); self.dtype=dtype; self.pre=self.post=None
        self.profile=False; self.events=[]

    def bind(self, core, groups):
        self.pre=core.pre_log_gain.exp()[groups].to(self.dtype)
        self.post=core.post_log_gain.exp()[groups].to(self.dtype)

    def __matmul__(self,x):
        if self.profile:
            a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True);a.record()
        y=((self.base @ (x.to(self.dtype)*self.pre[:,None]))*self.post[:,None]).float()
        if self.profile: b.record();self.events.append((a,b))
        return y


def structure_matrix(matrix, kind, seed=10):
    """Controls operate on the effective graph; preserve labelled neurons and signs.

    Rewire by directed double-edge swaps within presynaptic-sign strata. This
    exactly preserves binary in/out degrees, each source's sign and weight multiset.
    It does not claim to preserve target weighted strengths or spatial locality.
    """
    import scipy.sparse as sp
    rng=np.random.default_rng(seed)
    w=matrix.tocoo(copy=True); mask=w.data!=0
    row=w.row[mask].copy();col=w.col[mask].copy();val=w.data[mask].copy()
    before_out=np.bincount(col,minlength=w.shape[0]);before_in=np.bincount(row,minlength=w.shape[0])
    before_sign=np.sign(val)
    audit=dict(kind=kind,nonzero_edges=len(val),seed=seed)
    if kind=='weight_shuffle':
        for sign in (-1,1):
            ids=np.flatnonzero(before_sign==sign);val[ids]=val[rng.permutation(ids)]
        audit.update(topology_unchanged=True,global_sign_specific_weights_preserved=True)
    elif kind=='rewired':
        # Vectorized permutation proposal followed by duplicate rejection. Each round
        # swaps disjoint pairs, then rejects every pair that introduces a parallel edge.
        swaps=0
        for _ in range(3):
            a=rng.choice(len(val),size=min(1000000,len(val)//2),replace=False)
            a=a[:len(a)//2*2].reshape(-1,2);i,j=a[:,0],a[:,1]
            ok=(before_sign[i]==before_sign[j])&(col[i]!=col[j])&(row[i]!=row[j])
            i,j=i[ok],j[ok]
            oldi,oldj=row[i].copy(),row[j].copy();row[i],row[j]=oldj,oldi
            keys=row.astype('int64')*w.shape[0]+col
            _,inv,counts=np.unique(keys,return_inverse=True,return_counts=True)
            bad=(counts[inv[i]]>1)|(counts[inv[j]]>1)|(row[i]==col[i])|(row[j]==col[j])
            row[i[bad]],row[j[bad]]=oldi[bad],oldj[bad];swaps+=int((~bad).sum())
        audit.update(successful_edge_swaps=swaps,presynaptic_weight_multisets_preserved=True,
                     target_weighted_strength_preserved=False,spatial_locality_preserved=False)
    else: raise ValueError(kind)
    assert np.array_equal(before_out,np.bincount(col,minlength=w.shape[0]))
    assert np.array_equal(before_in,np.bincount(row,minlength=w.shape[0]))
    assert np.array_equal(before_sign,np.sign(val))
    audit.update(in_degree_exact=True,out_degree_exact=True,edge_signs_exact=True,
        absolute_weight_quantiles=np.quantile(np.abs(val),[0,.25,.5,.75,1]).tolist())
    result=sp.coo_matrix((val,(row,col)),shape=w.shape).tocsr()
    assert result.nnz==len(val)
    return result,audit


class StudyBrain(FullBrain):
    def __init__(self,batch=16,precision='float64',structure='real',metadata_dir=None):
        t=time.perf_counter()
        super().__init__(ROOT/'archive/experiments/campaign/run',batch=batch,persist_mapping=False)
        base=self.matrix.base
        if structure!='real':
            w,audit=structure_matrix(self.brain._W_cpu,structure)
            base=self.brain._sparse(w,torch.float32)
            if metadata_dir: write(metadata_dir/'structure.json',audit)
        self.precision=precision
        self.matrix=Matrix(base,{'float32':torch.float32,'float64':torch.float64}[precision])
        self.brain.W=self.matrix
        # Drop the unused double-precision reference when the candidate uses FP32.
        self.reference=None
        self.counts=dict(forward_calls=0,neuron_ms=0,gradient_forward_calls=0,transfer_seconds=0.)
        self.initialization_seconds=time.perf_counter()-t
        if metadata_dir:
            metadata=dict(self.metadata,precision=precision,structure=structure,batch=batch,
                lif=dataclasses.asdict(self.params),slow_active=self.brain._slow_active,
                std_active=self.brain._std_on,K=self.brain.K,n_delay=self.brain.n_delay,
                adaptation_jump_range=[float(self.brain.adapt_jump_vec.min()),float(self.brain.adapt_jump_vec.max())]
                    if self.brain.adapt_jump_vec is not None else None,
                initialization_seconds=self.initialization_seconds)
            write(metadata_dir/'brain.json',metadata)
            np.savez_compressed(metadata_dir/'resolved-dynamics.npz',
                adapt_jump=self.brain.adapt_jump_vec.cpu().numpy() if self.brain.adapt_jump_vec is not None else [],
                std_u=self.brain.std_u_vec.cpu().numpy(),active=self.brain.active.cpu().numpy())

    def bind(self):
        self.matrix.bind(self.core,self.neuron_group);self.brain.W=self.matrix
        self.params.v_th=self.base_threshold+self.core.threshold_mv[self.neuron_group]

    def reset(self):
        self.brain.reset();self.brain.t=0.;self.brain.step_count=self.brain.buf_pos=0

    def advance(self,boards,ms=40,reset=False,hook=None):
        if boards.shape!=(self.batch,4,10,10): raise ValueError('Incorrect brain batch')
        self.bind()
        if reset: self.reset()
        self.brain.set_drive(self.input_index,boards.reshape(self.batch,400).repeat_interleave(8,1)*18)
        self.counts['forward_calls']+=1;self.counts['neuron_ms']+=self.batch*167106*ms
        self.counts['gradient_forward_calls']+=int(torch.is_grad_enabled())
        if ms==40 and hook is None:
            self.brain.run_ms(14);current=self.brain.g[:,self.observed]
            self.brain.run_ms(26)
        else:
            current=None
            for i in range(ms):
                self.brain.step()
                if i==13: current=self.brain.g[:,self.observed]
                if hook: hook(self.brain,i+1)
            if current is None: current=self.brain.g[:,self.observed]
        voltage=self.brain.v[:,self.observed]-self.params.v_rest
        return torch.cat((current.reshape(self.batch,256,16).mean(2),voltage.reshape(self.batch,256,16).mean(2)),1)

    def forward(self,boards,**kwargs):
        return self.advance(boards,reset=True)

    def encode(self,boards,check=lambda:None):
        features=[]
        with torch.no_grad():
            for start in range(0,len(boards),self.batch):
                check();part=boards[start:start+self.batch]
                x=np.zeros((self.batch,4,10,10),dtype='float32');x[:len(part)]=part
                t=time.perf_counter();x=torch.from_numpy(x).cuda();self.counts['transfer_seconds']+=time.perf_counter()-t
                features.append(self.forward(x)[:len(part)].cpu().numpy())
        return np.concatenate(features)

    def capture_state(self,detach=False):
        take=lambda t:t.detach().clone() if detach else t.clone()
        return dict(tensors={n:take(getattr(self.brain,n)) for n in STATE_FIELDS},
            acc={k:take(v) for k,v in self.brain._acc.items()},
            t=self.brain.t,step_count=self.brain.step_count,buf_pos=self.brain.buf_pos,
            poisson_on=self.brain._poisson_on,generator=self.brain.gen.get_state().clone())

    def restore_state(self,s):
        for name,value in s['tensors'].items(): setattr(self.brain,name,value.clone())
        self.brain._acc={k:v.clone() for k,v in s['acc'].items()}
        for name in ('t','step_count','buf_pos'):setattr(self.brain,name,s[name])
        self.brain._poisson_on=s['poisson_on'];self.brain.gen.set_state(s['generator'])
        self.brain._rate_np_key=None

    def intervene(self,part,rows=None):
        b=self.brain
        fields={'voltage':['v'],'current':['g','g_slow','g_slow_cls'],
                'adaptation':['adapt'],'delay':['spike_buf'],'all':list(STATE_FIELDS)}[part]
        for name in fields:
            value=getattr(b,name).clone()
            fill=self.params.v_rest if name=='v' else 1. if name=='res' else 0.
            if rows is None:value.fill_(fill)
            elif name in ('g_slow_cls','spike_buf'):value[:,rows]=fill
            else:value[rows]=fill
            setattr(b,name,value)
        if part=='all':
            b._acc={k:torch.zeros_like(v) for k,v in b._acc.items()}
            b._poisson_on=False


class BoardMLP(nn.Module):
    """400 -> 92 -> 4 = 37,264 parameters vs brain+readout 37,362."""
    architecture='board_mlp_400_92_4'
    def __init__(self):
        super().__init__();self.net=nn.Sequential(nn.Linear(400,92),nn.ReLU(),nn.Linear(92,4))
    def forward(self,x,**kwargs):return output(self.net(x.reshape(len(x),400)))


class BoardEncoder:
    batch=128
    core=None
    counts={}
    def encode(self,boards,check=lambda:None):check();return np.asarray(boards,dtype='float32').reshape(-1,400)
    def release_graph(self):pass


def initialize(config,out):
    from common import configure
    configure(10)
    free,total=torch.cuda.mem_get_info()
    if free<13*2**30:raise RuntimeError('resource_gate: less than 13 GiB free GPU memory')
    torch.cuda.set_per_process_memory_fraction(11*2**30/total)
    if config['condition']['model']=='board_mlp':
        return BoardEncoder(),BoardMLP().cuda()
    encoder=StudyBrain(config['batch'],config['precision'],config['condition']['structure'],out)
    head=ActivityLinear().cuda()
    return encoder,head


def set_pair(encoder,head,pair):
    if encoder.core is not None:encoder.set_core(pair['core'])
    head.load_state_dict(pair['head'])


def pair(encoder,head):
    return dict(core=cpu_state(encoder.core) if encoder.core is not None else {},head=cpu_state(head))
